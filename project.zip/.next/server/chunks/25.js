exports.id = 25;
exports.ids = [25];
exports.modules = {

/***/ 3417:
/***/ ((module) => {

// Exports
module.exports = {
	"addRequestBtn": "AddRequestBtn_addRequestBtn__jK595"
};


/***/ }),

/***/ 5410:
/***/ ((module) => {

// Exports
module.exports = {
	"loadingScreen": "LoadingScreen_loadingScreen__NlU75",
	"spinner": "LoadingScreen_spinner__kP0uk",
	"spin": "LoadingScreen_spin__G4yIC"
};


/***/ }),

/***/ 1252:
/***/ ((module) => {

// Exports
module.exports = {
	"sideNav": "SideNav_sideNav__j0XPo",
	"navlinksContainer": "SideNav_navlinksContainer__FXnp2",
	"navlinks": "SideNav_navlinks__S6gyV",
	"hideMenuBtn": "SideNav_hideMenuBtn__27cei",
	"showMenuBtn": "SideNav_showMenuBtn__3ncMd",
	"innerLogo": "SideNav_innerLogo__qLxOf"
};


/***/ }),

/***/ 5508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo.cb57c663.png","height":75,"width":195,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAVklEQVR4nBWMOwqAQBBDkwVh11qxtLLwcl7VziN4AVFBZLOZIjDz8uGzLZ2kxMQCgKq6EtnLz1+FCMwkVgilmhH47A1mR57yHoFsMFqxcFtRLiBeX2cD68Aaz2rgEecAAAAASUVORK5CYII="});

/***/ }),

/***/ 5168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _LoadingScreen_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5410);
/* harmony import */ var _LoadingScreen_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_LoadingScreen_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_logo_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5508);





const LoadingScreen = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_LoadingScreen_module_css__WEBPACK_IMPORTED_MODULE_4___default().loadingScreen),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: _public_logo_png__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                    alt: "Logo Vidvie",
                    width: 250,
                    objectFit: "cover"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "title",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_LoadingScreen_module_css__WEBPACK_IMPORTED_MODULE_4___default().spinner)
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoadingScreen);


/***/ }),

/***/ 1765:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);


const RenderIf = ({ isTrue , otherChoice , children  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    return isTrue ? children : otherChoice;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RenderIf);


/***/ }),

/***/ 5025:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "V": () => (/* binding */ AuthContext),
  "H": () => (/* binding */ AuthProvider)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "jwt-decode"
var external_jwt_decode_ = __webpack_require__(5567);
var external_jwt_decode_default = /*#__PURE__*/__webpack_require__.n(external_jwt_decode_);
// EXTERNAL MODULE: ./components/LoadingScreen/LoadingScreen.jsx
var LoadingScreen = __webpack_require__(5168);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/SideNav/SideNav.module.css
var SideNav_module = __webpack_require__(1252);
var SideNav_module_default = /*#__PURE__*/__webpack_require__.n(SideNav_module);
// EXTERNAL MODULE: ./public/logo.png
var logo = __webpack_require__(5508);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "@fortawesome/react-fontawesome"
var react_fontawesome_ = __webpack_require__(7197);
// EXTERNAL MODULE: external "@fortawesome/free-solid-svg-icons"
var free_solid_svg_icons_ = __webpack_require__(6466);
;// CONCATENATED MODULE: ./public/logo-VIDVIE-icon.png
/* harmony default export */ const logo_VIDVIE_icon = ({"src":"/_next/static/media/logo-VIDVIE-icon.4ac72475.png","height":500,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAflBMVEXzbSXzbSTybSTybCTzbSTybSTybSTzbSXzbSTybSTzbSTzbSXybSTzbSTybCTybSTzbSTybCTybCTzbSTybSTybSTybCTybSTybCTybCTybCTybSTybSTybSTzbSTzbSTybSTzbSTzbSTzbSTzbSTybSTzbSTzbSTybCTybSTnF7ZsAAAAKnRSTlMAAAAAAQECAwMDBAgJCg0iJisuMDE3QkROV15qa3eBhYWQsre7vsjb3PfEgcDZAAAAQ0lEQVR42gVAhRGAMBDLp2hxd6fI/gv20NwRmZoa/AayugSynEpNPcHsTdQeEz6eNp+poWU7xoIOPJb/ykDgCk3HUCyO7AOy4JAtkgAAAABJRU5ErkJggg=="});
// EXTERNAL MODULE: ./components/RenderIf.jsx
var RenderIf = __webpack_require__(1765);
;// CONCATENATED MODULE: ./components/SideNav/SideNav.jsx











const SideNav = ()=>{
    const { isAuthenticated  } = (0,external_react_.useContext)(AuthContext);
    const chkRef = (0,external_react_.useRef)();
    (0,external_react_.useEffect)(()=>{
        let startPos, endPos;
        window.addEventListener("touchstart", (e)=>{
            startPos = e.changedTouches[0].clientX;
        });
        window.addEventListener("touchend", (e)=>{
            endPos = e.changedTouches[0].clientX;
            console.log(endPos - startPos);
            if (endPos - startPos > 150) {
                chkRef.current.checked = true;
            } else if (endPos - startPos < -150) {
                chkRef.current.checked = false;
            }
        });
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "checkbox",
                id: "chk",
                ref: chkRef
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                className: (SideNav_module_default()).sideNav,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            onClick: ()=>chkRef.current.checked = false
                            ,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: logo/* default */.Z,
                                alt: "Logo Vidvie",
                                objectFit: "cover"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(RenderIf/* default */.Z, {
                        isTrue: isAuthenticated,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (SideNav_module_default()).navlinksContainer,
                            onClick: ()=>chkRef.current.checked = false
                            ,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: (SideNav_module_default()).navlinks,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                children: "Tasks"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tasks/division/branding",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faPaintBrush
                                                        }),
                                                        " Branding"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tasks/division/direksi",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faUserFriends
                                                        }),
                                                        " Direksi"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tasks/division/distributor",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faTruck
                                                        }),
                                                        " Distributor"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tasks/division/ga",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faTasks
                                                        }),
                                                        " GA"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tasks/division/hrd",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faUsersCog
                                                        }),
                                                        " HRD"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tasks/division/online-marketing",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faGlobe
                                                        }),
                                                        " Online Marketing"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tasks/division/operational",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faFolder
                                                        }),
                                                        " Operational"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tasks/division/sales",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faTags
                                                        }),
                                                        " Sales"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tasks/division/store",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faStore
                                                        }),
                                                        " Store"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tasks/division/vidvie",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: logo_VIDVIE_icon,
                                                            height: 20,
                                                            width: 20,
                                                            alt: "Logo Vidvie"
                                                        }),
                                                        " Vidvie"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/tasks/division/others",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faEllipsis
                                                        }),
                                                        " Others"
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: (SideNav_module_default()).navlinks,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                children: "Staffs"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/divisions",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faUsersBetweenLines
                                                        }),
                                                        " Divisions"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/account",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faUser
                                                        }),
                                                        " Account"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/stocks",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faBoxOpen
                                                        }),
                                                        " Stocks"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: "/account/logout",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                            icon: free_solid_svg_icons_.faSignIn
                                                        }),
                                                        " Logout"
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: (SideNav_module_default()).hideMenuBtn,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                                                icon: free_solid_svg_icons_.faTimes
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const SideNav_SideNav = (SideNav);

// EXTERNAL MODULE: ./components/AddRequestBtn/AddRequestBtn.module.css
var AddRequestBtn_module = __webpack_require__(3417);
var AddRequestBtn_module_default = /*#__PURE__*/__webpack_require__.n(AddRequestBtn_module);
;// CONCATENATED MODULE: ./components/AddRequestBtn/AddRequestBtn.jsx






const AddRequestBtn = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: "/tasks/add",
        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            className: (AddRequestBtn_module_default()).addRequestBtn,
            children: /*#__PURE__*/ jsx_runtime_.jsx(react_fontawesome_.FontAwesomeIcon, {
                icon: free_solid_svg_icons_.faPlus
            })
        })
    });
};
/* harmony default export */ const AddRequestBtn_AddRequestBtn = (AddRequestBtn);

;// CONCATENATED MODULE: ./context/AuthContext.jsx







const AuthContext = /*#__PURE__*/ (0,external_react_.createContext)();
const AuthProvider = ({ children  })=>{
    const { 0: isAuthenticated , 1: setIsAuthenticated  } = (0,external_react_.useState)(false);
    const { 0: authToken , 1: setAuthToken  } = (0,external_react_.useState)({});
    const { 0: user , 1: setUser  } = (0,external_react_.useState)("");
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(true);
    const router = (0,router_.useRouter)();
    const loginUser = async (username, password)=>{
        if (!username || !password) return;
        try {
            let response = await fetch("/api/auth/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    "username": username,
                    "password": password
                })
            });
            let data = await response.json();
            if (response.status === 200) {
                setAuthToken(data);
                const userData = external_jwt_decode_default()(data.access);
                setUser({
                    "username": userData.username,
                    "name": userData.name,
                    "division": userData.division,
                    "leader_of": userData.leader_of
                });
                setIsAuthenticated(true);
                router.replace("/");
                return [
                    "Login successful",
                    response.status
                ];
            } else {
                return [
                    data,
                    response.status
                ];
            }
        } catch (err) {
            console.error(err);
            logoutUser();
        }
    };
    const logoutUser = async ()=>{
        await fetch("/api/auth/logout", {
            method: "POST"
        });
        setUser("");
        setAuthToken("");
        setIsAuthenticated(false);
        router.replace("/account/login");
    };
    const refreshingToken = async ()=>{
        try {
            let response = await fetch("/api/auth/refresh", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                }
            });
            let data = await response.json();
            if (response.status === 200) {
                setAuthToken(data);
                const userData = external_jwt_decode_default()(data.access);
                setUser({
                    "username": userData.username,
                    "name": userData.name,
                    "division": userData.division,
                    "leader_of": userData.leader_of
                });
                setIsAuthenticated(true);
                setLoading(false);
                return data.access;
            } else {}
        } catch (err) {
            console.error(err);
            logoutUser();
        }
        setLoading(false);
    };
    const contextData = {
        user: user,
        authToken: authToken,
        isAuthenticated: isAuthenticated,
        loginUser: loginUser,
        logoutUser: logoutUser,
        refreshingToken: refreshingToken,
        loading: loading,
        setLoading: setLoading
    };
    (0,external_react_.useEffect)(()=>{
        refreshingToken();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(AuthContext.Provider, {
        value: contextData,
        children: loading ? /*#__PURE__*/ jsx_runtime_.jsx(LoadingScreen/* default */.Z, {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
            className: "main-content",
            style: {
                WebkitTapHighlightColor: "transparent"
            },
            children: [
                isAuthenticated ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(SideNav_SideNav, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(AddRequestBtn_AddRequestBtn, {})
                    ]
                }) : null,
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "children",
                    style: {
                        padding: isAuthenticated ? "10px" : "0"
                    },
                    children: children
                })
            ]
        })
    });
};


/***/ })

};
;