exports.id = 198;
exports.ids = [198];
exports.modules = {

/***/ 286:
/***/ ((module) => {

// Exports
module.exports = {
	"tasks": "Tasks_tasks__KXjxV",
	"taskContainer": "Tasks_taskContainer__y5ZtZ",
	"taskTitle": "Tasks_taskTitle__L2xPG",
	"upperDetail": "Tasks_upperDetail__5QS3z",
	"priorityAndStatus": "Tasks_priorityAndStatus__5oNT_",
	"priority": "Tasks_priority__pHofb",
	"status": "Tasks_status__gRyS_"
};


/***/ }),

/***/ 9399:
/***/ ((module) => {

// Exports
module.exports = {
	"filterForm": "Home_filterForm__BoCx_"
};


/***/ }),

/***/ 241:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Tasks_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(286);
/* harmony import */ var _Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);





const Tasks = ({ tasks , division , isLeader , inTaskbyDivisionPage , setRefetching  })=>{
    const changeTaskStatus = async (e, task)=>{
        e.preventDefault();
        try {
            await axios__WEBPACK_IMPORTED_MODULE_3___default().post(`${"https://backend.management.vidvie.co.id/api"}/tasks/${task.id}`, {
                "title": task.title,
                "description": task.description,
                "priority": task.priority,
                "status": e.target.value,
                "deadline": task.deadline,
                "requestor_division": typeof task.requestor_division === "object" ? task.requestor_division.name : task.requestor,
                "requestee_division": typeof task.requestee_division === "object" ? task.requestee_division.name : task.requestee
            });
        } catch (err) {
            console.error(err);
        }
        setRefetching(true);
    };
    const changeTaskPriority = async (e, task)=>{
        e.preventDefault();
        try {
            await axios__WEBPACK_IMPORTED_MODULE_3___default().post(`${"https://backend.management.vidvie.co.id/api"}/tasks/${task.id}`, {
                "title": task.title,
                "description": task.description,
                "priority": e.target.value,
                "status": task.status,
                "deadline": task.deadline,
                "requestor_division": typeof task.requestor_division === "object" ? task.requestor_division.name : task.requestor,
                "requestee_division": typeof task.requestee_division === "object" ? task.requestee_division.name : task.requestee
            });
        } catch (err) {
            console.error(err);
        }
        setRefetching(true);
    };
    const setPriorityColor = (priority)=>{
        if (priority === "High") return "var(--status-not-started-background-color)";
        if (priority === "Medium") return "var(--status-shipping-background-color)";
        else return "var(--status-finished-background-color)";
    };
    const setStatusColor = (status)=>{
        if (status === "Not Started") return "#910810";
        if (status === "In Progress") return "var(--status-in-progress-background-color)";
        if (status === "Shipping") return "var(--status-shipping-background-color)";
        if (status === "Finished") return "var(--status-finished-background-color)";
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: (_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default().tasks),
            children: tasks.length > 0 ? tasks.map((task)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: (_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default().task),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default().taskContainer),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default().upperDetail),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: (_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default().taskTitle),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: `/tasks/${task.id}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                children: task.title
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default().priorityAndStatus),
                                        children: [
                                            isLeader ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                className: (_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default().status),
                                                style: {
                                                    backgroundColor: setPriorityColor(task.priority),
                                                    border: "none"
                                                },
                                                value: task.priority,
                                                onChange: (e)=>changeTaskPriority(e, task)
                                                ,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "High",
                                                        children: "High"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "Medium",
                                                        children: "Medium"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "Low",
                                                        children: "Low"
                                                    })
                                                ]
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: (_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default().priority),
                                                style: {
                                                    backgroundColor: setPriorityColor(task.priority)
                                                },
                                                children: task.priority
                                            }),
                                            isLeader ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                className: (_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default().status),
                                                style: {
                                                    backgroundColor: setStatusColor(task.status),
                                                    border: "none"
                                                },
                                                value: task.status,
                                                onChange: (e)=>changeTaskStatus(e, task)
                                                ,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "Not Started",
                                                        children: "Not Started"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "In Progress",
                                                        children: "In Progress"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "Shipping",
                                                        children: "Shipping"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "Finished",
                                                        children: "Finished"
                                                    })
                                                ]
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: (_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default().status),
                                                style: {
                                                    backgroundColor: setStatusColor(task.status)
                                                },
                                                children: task.status
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_Tasks_module_css__WEBPACK_IMPORTED_MODULE_4___default().details),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            "Requested by : ",
                                            task.requestor_division.name
                                        ]
                                    }),
                                    !inTaskbyDivisionPage ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            "Requested to : ",
                                            task.requestee_division.name
                                        ]
                                    }) : null,
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            "Date Added : ",
                                            new Date(task.date_added).toLocaleString()
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        children: [
                                            "Deadline : ",
                                            new Date(task.deadline).toLocaleString()
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }, task.id);
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    children: "No tasks"
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Tasks);


/***/ }),

/***/ 5871:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Title = ({ text  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
        className: "title",
        children: text
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Title);


/***/ })

};
;