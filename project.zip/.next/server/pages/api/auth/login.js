"use strict";
(() => {
var exports = {};
exports.id = 908;
exports.ids = [908];
exports.modules = {

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 6205:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{
    if (req.method === "POST") {
        const { username , password  } = req.body;
        try {
            let response = await fetch(`${"https://backend.management.vidvie.co.id/api"}/token`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    "username": username,
                    "password": password
                })
            });
            let data = await response.json();
            if (response.status === 200) {
                res.setHeader("Set-Cookie", [
                    cookie__WEBPACK_IMPORTED_MODULE_0___default().serialize("refresh", data.refresh, {
                        httpOnly: true,
                        sameSite: "strict",
                        secure: "production" !== "development",
                        maxAge: 60 * 60 * 24,
                        path: "/api/"
                    })
                ]);
                return res.status(200).json(data);
            } else {
                return res.status(response.status).json({
                    message: "Authentication failed"
                });
            }
        } catch (err) {
            return res.status(500).json(err);
        }
    } else {
        res.setHeader("Allow", [
            "POST"
        ]);
        return res.status(405).json({
            error: `Method ${req.method} not allowed`
        });
    }
});


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6205));
module.exports = __webpack_exports__;

})();