"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth/login";
exports.ids = ["pages/api/auth/login"];
exports.modules = {

/***/ "cookie":
/*!*************************!*\
  !*** external "cookie" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ "(api)/./pages/api/auth/login.js":
/*!*********************************!*\
  !*** ./pages/api/auth/login.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cookie */ \"cookie\");\n/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_0__);\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{\n    if (req.method === \"POST\") {\n        const { username , password  } = req.body;\n        try {\n            let response = await fetch(`${\"https://vidvie-management-backend.herokuapp.com/api\"}/token`, {\n                method: \"POST\",\n                headers: {\n                    \"Content-Type\": \"application/json\"\n                },\n                body: JSON.stringify({\n                    \"username\": username,\n                    \"password\": password\n                })\n            });\n            let data = await response.json();\n            if (response.status === 200) {\n                res.setHeader(\"Set-Cookie\", [\n                    cookie__WEBPACK_IMPORTED_MODULE_0___default().serialize(\"refresh\", data.refresh, {\n                        httpOnly: true,\n                        sameSite: \"strict\",\n                        secure: \"development\" !== \"development\",\n                        maxAge: 60 * 60 * 24,\n                        path: \"/api/\"\n                    })\n                ]);\n                return res.status(200).json(data);\n            } else {\n                return res.status(response.status).json({\n                    message: \"Authentication failed\"\n                });\n            }\n        } catch (err) {\n            return res.status(500).json(err);\n        }\n    } else {\n        res.setHeader(\"Allow\", [\n            \"POST\"\n        ]);\n        return res.status(405).json({\n            error: `Method ${req.method} not allowed`\n        });\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvYXV0aC9sb2dpbi5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBMkI7QUFFM0IsaUVBQWUsT0FBT0MsR0FBRyxFQUFFQyxHQUFHLEdBQUs7SUFDL0IsSUFBSUQsR0FBRyxDQUFDRSxNQUFNLEtBQUssTUFBTSxFQUFFO1FBQ3ZCLE1BQU0sRUFBRUMsUUFBUSxHQUFFQyxRQUFRLEdBQUUsR0FBR0osR0FBRyxDQUFDSyxJQUFJO1FBRXZDLElBQUk7WUFDQSxJQUFJQyxRQUFRLEdBQUcsTUFBTUMsS0FBSyxDQUFDLENBQUMsRUFBRUMscURBQW1DLENBQUMsTUFBTSxDQUFDLEVBQUM7Z0JBQ3RFTixNQUFNLEVBQUUsTUFBTTtnQkFDZFMsT0FBTyxFQUFFO29CQUNMLGNBQWMsRUFBRSxrQkFBa0I7aUJBQ3JDO2dCQUNETixJQUFJLEVBQUVPLElBQUksQ0FBQ0MsU0FBUyxDQUFDO29CQUFDLFVBQVUsRUFBQ1YsUUFBUTtvQkFBRSxVQUFVLEVBQUNDLFFBQVE7aUJBQUMsQ0FBQzthQUNuRSxDQUFDO1lBQ0YsSUFBSVUsSUFBSSxHQUFHLE1BQU1SLFFBQVEsQ0FBQ1MsSUFBSSxFQUFFO1lBQ2hDLElBQUlULFFBQVEsQ0FBQ1UsTUFBTSxLQUFLLEdBQUcsRUFBRTtnQkFDekJmLEdBQUcsQ0FBQ2dCLFNBQVMsQ0FBQyxZQUFZLEVBQUU7b0JBQ3hCbEIsdURBQWdCLENBQUMsU0FBUyxFQUFFZSxJQUFJLENBQUNLLE9BQU8sRUFBRTt3QkFDdENDLFFBQVEsRUFBRSxJQUFJO3dCQUNkQyxRQUFRLEVBQUUsUUFBUTt3QkFDbEJDLE1BQU0sRUFBRWQsYUFwQm5CLEtBb0I0QyxhQUFhO3dCQUM5Q2UsTUFBTSxFQUFFLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRTt3QkFDcEJDLElBQUksRUFBRSxPQUFPO3FCQUNoQixDQUFDO2lCQUNMLENBQUM7Z0JBQ0YsT0FBT3ZCLEdBQUcsQ0FBQ2UsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDRCxJQUFJLENBQUNELElBQUksQ0FBQzthQUNwQyxNQUFNO2dCQUNILE9BQU9iLEdBQUcsQ0FBQ2UsTUFBTSxDQUFDVixRQUFRLENBQUNVLE1BQU0sQ0FBQyxDQUFDRCxJQUFJLENBQUM7b0JBQUNVLE9BQU8sRUFBRSx1QkFBdUI7aUJBQUMsQ0FBQzthQUM5RTtTQUNKLENBQUMsT0FBT0MsR0FBRyxFQUFFO1lBQ1YsT0FBT3pCLEdBQUcsQ0FBQ2UsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDRCxJQUFJLENBQUNXLEdBQUcsQ0FBQztTQUNuQztLQUNKLE1BQU07UUFDSHpCLEdBQUcsQ0FBQ2dCLFNBQVMsQ0FBQyxPQUFPLEVBQUU7WUFBQyxNQUFNO1NBQUMsQ0FBQyxDQUFDO1FBQ2pDLE9BQU9oQixHQUFHLENBQUNlLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQ0QsSUFBSSxDQUFDO1lBQUNZLEtBQUssRUFBRSxDQUFDLE9BQU8sRUFBRTNCLEdBQUcsQ0FBQ0UsTUFBTSxDQUFDLFlBQVksQ0FBQztTQUFDLENBQUM7S0FDM0U7Q0FDSiIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2plY3QtbWFuYWdlbWVudC1mcm9udGVuZC8uL3BhZ2VzL2FwaS9hdXRoL2xvZ2luLmpzPzEzMTciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGNvb2tpZSBmcm9tICdjb29raWUnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBhc3luYyAocmVxLCByZXMpID0+IHtcclxuICAgIGlmIChyZXEubWV0aG9kID09PSAnUE9TVCcpIHtcclxuICAgICAgICBjb25zdCB7IHVzZXJuYW1lLCBwYXNzd29yZCB9ID0gcmVxLmJvZHlcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQkFDS0VORF9VUkx9L3Rva2VuYCx7XHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsndXNlcm5hbWUnOnVzZXJuYW1lLCAncGFzc3dvcmQnOnBhc3N3b3JkfSlcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgbGV0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKClcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICByZXMuc2V0SGVhZGVyKCdTZXQtQ29va2llJywgW1xyXG4gICAgICAgICAgICAgICAgICAgIGNvb2tpZS5zZXJpYWxpemUoJ3JlZnJlc2gnLCBkYXRhLnJlZnJlc2gsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHR0cE9ubHk6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNhbWVTaXRlOiAnc3RyaWN0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VjdXJlOiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ2RldmVsb3BtZW50JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4QWdlOiA2MCAqIDYwICogMjQgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAnL2FwaS8nXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIF0pXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzLnN0YXR1cygyMDApLmpzb24oZGF0YSlcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXMuc3RhdHVzKHJlc3BvbnNlLnN0YXR1cykuanNvbih7bWVzc2FnZTogJ0F1dGhlbnRpY2F0aW9uIGZhaWxlZCd9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIHJldHVybiByZXMuc3RhdHVzKDUwMCkuanNvbihlcnIpXHJcbiAgICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXMuc2V0SGVhZGVyKCdBbGxvdycsIFsnUE9TVCddKTtcclxuICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDUpLmpzb24oe2Vycm9yOiBgTWV0aG9kICR7cmVxLm1ldGhvZH0gbm90IGFsbG93ZWRgfSlcclxuICAgIH1cclxufSJdLCJuYW1lcyI6WyJjb29raWUiLCJyZXEiLCJyZXMiLCJtZXRob2QiLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwiYm9keSIsInJlc3BvbnNlIiwiZmV0Y2giLCJwcm9jZXNzIiwiZW52IiwiTkVYVF9QVUJMSUNfQkFDS0VORF9VUkwiLCJoZWFkZXJzIiwiSlNPTiIsInN0cmluZ2lmeSIsImRhdGEiLCJqc29uIiwic3RhdHVzIiwic2V0SGVhZGVyIiwic2VyaWFsaXplIiwicmVmcmVzaCIsImh0dHBPbmx5Iiwic2FtZVNpdGUiLCJzZWN1cmUiLCJtYXhBZ2UiLCJwYXRoIiwibWVzc2FnZSIsImVyciIsImVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/auth/login.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/auth/login.js"));
module.exports = __webpack_exports__;

})();