"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth/refresh";
exports.ids = ["pages/api/auth/refresh"];
exports.modules = {

/***/ "cookie":
/*!*************************!*\
  !*** external "cookie" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ "(api)/./pages/api/auth/refresh.js":
/*!***********************************!*\
  !*** ./pages/api/auth/refresh.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cookie */ \"cookie\");\n/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_0__);\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{\n    if (req.method === \"POST\") {\n        const cookies = cookie__WEBPACK_IMPORTED_MODULE_0___default().parse(req.headers.cookie ?? \"\");\n        const refresh = cookies.refresh ?? false;\n        if (refresh === false) {\n            return res.status(401).json({\n                error: \"User unauthorized\"\n            });\n        }\n        try {\n            let response = await fetch(`${\"https://vidvie-management-backend.herokuapp.com/api\"}/token/refresh`, {\n                method: \"POST\",\n                headers: {\n                    \"Content-Type\": \"application/json\"\n                },\n                body: JSON.stringify({\n                    \"refresh\": refresh\n                })\n            });\n            let data = await response.json();\n            if (response.status === 200) {\n                res.setHeader(\"Set-Cookie\", [\n                    cookie__WEBPACK_IMPORTED_MODULE_0___default().serialize(\"refresh\", data.refresh, {\n                        httpOnly: true,\n                        sameSite: \"strict\",\n                        maxAge: 60 * 60 * 24,\n                        secure: \"development\" !== \"development\",\n                        path: \"/api/\"\n                    })\n                ]);\n                return res.status(200).json(data);\n            } else {\n                return res.status(response.status).json(data);\n            }\n        } catch (err) {\n            console.error(err);\n            return res.status(500).json(err);\n        }\n    } else {\n        res.setHeader(\"Allow\", [\n            \"POST\"\n        ]);\n        return res.status(405).json({\n            error: `Method ${req.method} not allowed`\n        });\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvYXV0aC9yZWZyZXNoLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUEyQjtBQUUzQixpRUFBZSxPQUFPQyxHQUFHLEVBQUVDLEdBQUcsR0FBSztJQUMvQixJQUFJRCxHQUFHLENBQUNFLE1BQU0sS0FBSyxNQUFNLEVBQUU7UUFDdkIsTUFBTUMsT0FBTyxHQUFHSixtREFBWSxDQUFDQyxHQUFHLENBQUNLLE9BQU8sQ0FBQ04sTUFBTSxJQUFJLEVBQUUsQ0FBQztRQUV0RCxNQUFNTyxPQUFPLEdBQUdILE9BQU8sQ0FBQ0csT0FBTyxJQUFJLEtBQUs7UUFFeEMsSUFBSUEsT0FBTyxLQUFLLEtBQUssRUFBRTtZQUNuQixPQUFPTCxHQUFHLENBQUNNLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQ0MsSUFBSSxDQUFDO2dCQUFDQyxLQUFLLEVBQUUsbUJBQW1CO2FBQUMsQ0FBQztTQUM1RDtRQUVELElBQUk7WUFDQSxJQUFJQyxRQUFRLEdBQUcsTUFBTUMsS0FBSyxDQUFDLENBQUMsRUFBRUMscURBQW1DLENBQUMsY0FBYyxDQUFDLEVBQUM7Z0JBQzlFVixNQUFNLEVBQUUsTUFBTTtnQkFDZEcsT0FBTyxFQUFFO29CQUNMLGNBQWMsRUFBRSxrQkFBa0I7aUJBQ3JDO2dCQUNEVSxJQUFJLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO29CQUFDLFNBQVMsRUFBRVgsT0FBTztpQkFBQyxDQUFDO2FBQzdDLENBQUM7WUFDRixJQUFJWSxJQUFJLEdBQUcsTUFBTVIsUUFBUSxDQUFDRixJQUFJLEVBQUU7WUFDaEMsSUFBSUUsUUFBUSxDQUFDSCxNQUFNLEtBQUssR0FBRyxFQUFFO2dCQUN6Qk4sR0FBRyxDQUFDa0IsU0FBUyxDQUFDLFlBQVksRUFBRTtvQkFDeEJwQix1REFBZ0IsQ0FDWixTQUFTLEVBQUVtQixJQUFJLENBQUNaLE9BQU8sRUFBRTt3QkFDckJlLFFBQVEsRUFBRSxJQUFJO3dCQUNkQyxRQUFRLEVBQUUsUUFBUTt3QkFDbEJDLE1BQU0sRUFBRSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUU7d0JBQ3BCQyxNQUFNLEVBQUVaLGFBNUJ2QixLQTRCZ0QsYUFBYTt3QkFDOUNhLElBQUksRUFBRSxPQUFPO3FCQUNoQixDQUNKO2lCQUNKLENBQUM7Z0JBQ0YsT0FBT3hCLEdBQUcsQ0FBQ00sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxJQUFJLENBQUNVLElBQUksQ0FBQzthQUNwQyxNQUFNO2dCQUNILE9BQU9qQixHQUFHLENBQUNNLE1BQU0sQ0FBQ0csUUFBUSxDQUFDSCxNQUFNLENBQUMsQ0FBQ0MsSUFBSSxDQUFDVSxJQUFJLENBQUM7YUFDaEQ7U0FDSixDQUFDLE9BQU9RLEdBQUcsRUFBRTtZQUNWQyxPQUFPLENBQUNsQixLQUFLLENBQUNpQixHQUFHLENBQUM7WUFDbEIsT0FBT3pCLEdBQUcsQ0FBQ00sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxJQUFJLENBQUNrQixHQUFHLENBQUM7U0FDbkM7S0FFSixNQUFNO1FBQ0h6QixHQUFHLENBQUNrQixTQUFTLENBQUMsT0FBTyxFQUFFO1lBQUMsTUFBTTtTQUFDLENBQUMsQ0FBQztRQUNqQyxPQUFPbEIsR0FBRyxDQUFDTSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUNDLElBQUksQ0FBQztZQUFDQyxLQUFLLEVBQUUsQ0FBQyxPQUFPLEVBQUVULEdBQUcsQ0FBQ0UsTUFBTSxDQUFDLFlBQVksQ0FBQztTQUFDLENBQUM7S0FDM0U7Q0FDSiIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2plY3QtbWFuYWdlbWVudC1mcm9udGVuZC8uL3BhZ2VzL2FwaS9hdXRoL3JlZnJlc2guanM/ZjcwYyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgY29va2llIGZyb20gJ2Nvb2tpZSdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIChyZXEsIHJlcykgPT4ge1xyXG4gICAgaWYgKHJlcS5tZXRob2QgPT09ICdQT1NUJykge1xyXG4gICAgICAgIGNvbnN0IGNvb2tpZXMgPSBjb29raWUucGFyc2UocmVxLmhlYWRlcnMuY29va2llID8/ICcnKVxyXG5cclxuICAgICAgICBjb25zdCByZWZyZXNoID0gY29va2llcy5yZWZyZXNoID8/IGZhbHNlXHJcblxyXG4gICAgICAgIGlmIChyZWZyZXNoID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDEpLmpzb24oe2Vycm9yOiAnVXNlciB1bmF1dGhvcml6ZWQnfSlcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0JBQ0tFTkRfVVJMfS90b2tlbi9yZWZyZXNoYCx7XHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1wicmVmcmVzaFwiOiByZWZyZXNofSlcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgbGV0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKClcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAwKSB7XHJcbiAgICAgICAgICAgICAgICByZXMuc2V0SGVhZGVyKCdTZXQtQ29va2llJywgW1xyXG4gICAgICAgICAgICAgICAgICAgIGNvb2tpZS5zZXJpYWxpemUoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdyZWZyZXNoJywgZGF0YS5yZWZyZXNoLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodHRwT25seTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNhbWVTaXRlOiAnc3RyaWN0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heEFnZTogNjAgKiA2MCAqIDI0ICxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlY3VyZTogcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdkZXZlbG9wbWVudCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXRoOiAnL2FwaS8nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICBdKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoMjAwKS5qc29uKGRhdGEpXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyhyZXNwb25zZS5zdGF0dXMpLmpzb24oZGF0YSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycilcclxuICAgICAgICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNTAwKS5qc29uKGVycilcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlcy5zZXRIZWFkZXIoJ0FsbG93JywgWydQT1NUJ10pO1xyXG4gICAgICAgIHJldHVybiByZXMuc3RhdHVzKDQwNSkuanNvbih7ZXJyb3I6IGBNZXRob2QgJHtyZXEubWV0aG9kfSBub3QgYWxsb3dlZGB9KVxyXG4gICAgfVxyXG59Il0sIm5hbWVzIjpbImNvb2tpZSIsInJlcSIsInJlcyIsIm1ldGhvZCIsImNvb2tpZXMiLCJwYXJzZSIsImhlYWRlcnMiLCJyZWZyZXNoIiwic3RhdHVzIiwianNvbiIsImVycm9yIiwicmVzcG9uc2UiLCJmZXRjaCIsInByb2Nlc3MiLCJlbnYiLCJORVhUX1BVQkxJQ19CQUNLRU5EX1VSTCIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwiZGF0YSIsInNldEhlYWRlciIsInNlcmlhbGl6ZSIsImh0dHBPbmx5Iiwic2FtZVNpdGUiLCJtYXhBZ2UiLCJzZWN1cmUiLCJwYXRoIiwiZXJyIiwiY29uc29sZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/auth/refresh.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/auth/refresh.js"));
module.exports = __webpack_exports__;

})();